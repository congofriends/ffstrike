$(function(){
  $("a[rel='tooltip']" ).tooltip();
})
;
