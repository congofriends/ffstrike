$(document).ready(function() {
   $('.flash').css('position', 'absolute');
   $('.flash').css('left', 200);
   $('.flash').css('right', 200);
   $('.flash').css('margin-left', 'auto');
   $('.flash').css('margin-right', 'auto');
   $('.flash').css('z-index', '9999');
   $('.flash').delay(1300).fadeOut();
});
