$(function() {
    $( ".timepicker" ).timepicker();
});
