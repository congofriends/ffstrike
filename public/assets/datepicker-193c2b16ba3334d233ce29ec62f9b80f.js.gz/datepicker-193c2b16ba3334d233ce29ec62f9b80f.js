$(function() {
    $( ".datepicker" ).datepicker();
});
